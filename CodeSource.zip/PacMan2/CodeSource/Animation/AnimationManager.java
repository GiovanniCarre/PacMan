package Animation;

import Moteur.Agent;

public class AnimationManager {
	public static void work(Agent e) {
		String s = e.getClass().getSimpleName()+e.getState().name();
	
		if (e.getAnimationTime() < AnimationData.getTimeAnim().get(s))
			e.incAnimationTime();
		else {
			e.resetAnimationTime();
			if (e.getAnimationNumber() < AnimationData.getNumberAnim().get(s))
				e.incAnimationNumber();
			else
				e.resetAnimationNumber();
			e.setSprite(s+e.getAnimationNumber()+e.getPosition().directionToString());
		}
		

	}
}
