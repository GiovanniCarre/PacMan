package Animation;

public enum State {
	Walk, KnockOut, Affraid;
}
