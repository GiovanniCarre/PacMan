package Animation;

import java.util.HashMap;

public class AnimationData {

	// walk
	private static HashMap<String, Integer> numberAnim = new HashMap<>();// number of anim
	private static HashMap<String, Integer> timeAnim = new HashMap<>();// time

	public static void initialize() {
		numberAnim.clear();
		timeAnim.clear();

		numberAnim.put("FantomeAffraid", 2);
		timeAnim.put("FantomeAffraid", 8);

		numberAnim.put("PacManWalk", 2);
		timeAnim.put("PacManWalk", 8);

		numberAnim.put("FantomeWalk", 1);
		timeAnim.put("FantomeWalk", 8);

		numberAnim.put("FantomeKnockOut", 1);
		timeAnim.put("FantomeKnockOut", 8);

		numberAnim.put("PacManKnockOut", 3);
		timeAnim.put("PacManKnockOut", 16);

	}
	// getters and setters

	public static HashMap<String, Integer> getNumberAnim() {
		return numberAnim;
	}

	public static HashMap<String, Integer> getTimeAnim() {
		return timeAnim;
	}
}