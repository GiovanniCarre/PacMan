package Fabrique;

import Comportement.KeyBoard;
import Menu.Configuration;
import Moteur.Agent;
import Moteur.AgentAction;
import Moteur.Fantome;
import Moteur.PacMacGame;
import Moteur.PositionAgent;

public class FantomeFactory implements AgentFactory {
    private final Configuration c;

    public FantomeFactory(Configuration c) {
        this.c = c;
    }

    @Override
    public Agent createAgent(int x, int y, PacMacGame g) {
    	for (int i = 0; i < c.getRolePlayers().size(); i++) {
			if (c.getRolePlayers().get(i).equals("Fantome")) {
				c.getRolePlayers().remove(i);

				return new Fantome(new KeyBoard(g), new PositionAgent(x, y, AgentAction.NORTH), g);
			}
		}
		return new Fantome(FabriqueAgent.getComportement(c.getComportementGhost(), g),
				new PositionAgent(x, y, AgentAction.NORTH), g);

    }

}
