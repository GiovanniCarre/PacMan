package Fabrique;

import Moteur.Agent;
import Moteur.PacMacGame;

public interface AgentFactory {
    Agent createAgent(int x, int y, PacMacGame g);
}
