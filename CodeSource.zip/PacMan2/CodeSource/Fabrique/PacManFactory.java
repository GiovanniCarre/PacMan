package Fabrique;

import Comportement.KeyBoard;
import Menu.Configuration;
import Moteur.Agent;
import Moteur.AgentAction;
import Moteur.PacMacGame;
import Moteur.PacMan;
import Moteur.PositionAgent;

public class PacManFactory implements AgentFactory {
    private final Configuration c;

    public PacManFactory(Configuration c) {
        this.c = c;
    }

    @Override
    public Agent createAgent(int x, int y, PacMacGame g) {
    	for (int i = 0; i < c.getRolePlayers().size(); i++) {
			if (c.getRolePlayers().get(i).equals("Pac-Man")) {
				c.getRolePlayers().remove(i);
				return new PacMan(new KeyBoard(g), new PositionAgent(x, y, AgentAction.NORTH), g);
			}
		}
		return new PacMan(FabriqueAgent.getComportement(c.getComportementPacMan(), g),
				new PositionAgent(x, y, AgentAction.NORTH), g);
    }

}
