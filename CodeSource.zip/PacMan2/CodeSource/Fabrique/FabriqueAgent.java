package Fabrique;

import Comportement.Aleatoire;
import Comportement.Comportement;
import Comportement.FleeComportement;
import Comportement.FollowMouse;
import Comportement.goToFruitAndGomme;
import Comportement.moveToPacMan;
import Menu.Configuration;
import Moteur.Agent;
import Moteur.PacMacGame;

public class FabriqueAgent {
	private final AgentFactory pacManFactory;
	private final AgentFactory fantomeFactory;

	public FabriqueAgent(Configuration c) {
		this.pacManFactory = new PacManFactory(c);
		this.fantomeFactory = new FantomeFactory(c);
	}

	public Agent creerUnite(String type, int x, int y, PacMacGame g) {
		if (type.equals("PacMan")) {
			return pacManFactory.createAgent(x, y, g);
		} else if (type.equals("Fantome")) {
			return fantomeFactory.createAgent(x, y, g);
		} else {
			System.err.println("Agent \"" + type + "\" Indéfinie dans la fabrique");
			System.exit(0);
			return null;
		}
	}

	public static Comportement getComportement(String s, PacMacGame g) {
		if (s.equals("IA Aléatoire"))
			return new Aleatoire(g);
		else if (s.equals("A* sur les Pac-Man"))
			return new moveToPacMan(g);
		else if (s.equals("A sur les fruits"))
			return new goToFruitAndGomme(g);
		else if (s.equals("suit la souris"))
			return new FollowMouse(g);
		else if (s.equals("Fuire les pac-Man"))
			return new FleeComportement(g);
		// si non défini
		System.err.println("Comportement \"" + s + "\" Indéfinie dans la fabrique");
		System.exit(0);
		return null;
	}

}
