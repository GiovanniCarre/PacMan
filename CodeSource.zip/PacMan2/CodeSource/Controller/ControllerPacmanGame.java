package Controller;

import Comportement.FollowMouse;
import Graphics.PanelPacMan;
import Moteur.PacMacGame;

public class ControllerPacmanGame extends AbstractController {

	private final PacMacGame gamePacMan;

	public ControllerPacmanGame(PacMacGame game) {
		super.game = game;
		gamePacMan = game;
	}

	public void giveOrderMouseToGo(int x, int y) {
		if (!gamePacMan.getMaze().isWall(x, y))
			for (int i = 0; i < gamePacMan.getAgents().size(); i++)
				if (gamePacMan.getAgents().get(i).getComportement() instanceof FollowMouse) {
					FollowMouse comport = (FollowMouse) gamePacMan.getAgents().get(i).getComportement();
					comport.setArrival(x, y);
				}

	}

	public void stopGame() {
		PacMacGame.stop();
	}

	public void leftClick() {
		if (PacMacGame.isStop())
			gamePacMan.reset();
		else
			giveOrderMouseToGo(PanelPacMan.getInstance().getMousePosition().x / PanelPacMan.getSizeX(),
					PanelPacMan.getInstance().getMousePosition().y / PanelPacMan.getSizeY());

	}

}
