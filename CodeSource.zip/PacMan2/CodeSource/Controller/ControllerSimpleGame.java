package Controller;

import Moteur.Game;

public class ControllerSimpleGame extends AbstractController{

	public ControllerSimpleGame(Game game) {
		this.game = game;
	}
}
