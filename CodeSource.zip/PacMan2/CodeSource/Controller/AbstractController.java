package Controller;

import Moteur.Game;

public abstract class AbstractController {
	
	Game game;
	
	
	public void restart() {
		game.init();
		game.launch();
	}
	public void step() {
		game.step();
	}
	public void play() {
		game.launch();
	}
	public void pause() {
		game.pause();
	}
	
	public void setSpeed(double speed) {
		game.setSpeed(speed);
	}
	
}
