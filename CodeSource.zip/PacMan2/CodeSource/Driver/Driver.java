package Driver;

import Menu.MenuManager;
import Moteur.SimpleGame;

public class Driver {

	public static void main(String[] args) {
		launchMenu();

	}
	
	private static void launchSimpleGame() {
		SimpleGame game = new SimpleGame(20);
		game.init();
		game.launch();		
	}

	private static void launchMenu() {

		MenuManager.getInstance().init();

	}

}
