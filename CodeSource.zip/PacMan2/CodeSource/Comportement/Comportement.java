package Comportement;

import Moteur.Agent;
import Moteur.PacMacGame;

public abstract class Comportement {

	
	protected PacMacGame game;
	protected Agent agent;
	
	public Comportement(PacMacGame game) {
		this.game = game;
		
	}
	
	public abstract void move(Agent a);
	
}
