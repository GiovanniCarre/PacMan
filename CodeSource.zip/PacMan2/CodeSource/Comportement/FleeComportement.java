package Comportement;

import Moteur.Agent;
import Moteur.AgentAction;
import Moteur.PacMacGame;
import Moteur.PacMan;

public class FleeComportement extends Comportement {

	public FleeComportement(PacMacGame g) {
		super(g);
	}

	@Override
	public void move(Agent a) {

		// on cherche le pacMan le plus proche
		float minValue = 0;
		int minIndice = 0;
		Agent agent = null;

		// on recherche le pac-man le plus proche
		for (int i = 0; i < game.getAgents().size(); i++) {
			agent = game.getAgents().get(i);
			if (agent instanceof PacMan) {
				final int distance = AEtoile.distance((int) (agent.getX() + 0.5f), (int) (agent.getY() + 0.5f),
						(int) (a.getX() + 0.5f), (int) (a.getY() + 0.5f));
				if (distance < minValue) {
					minIndice = i;
					minValue = distance;
				}
			}
		}
		agent = game.getAgents().get(minIndice);

		// on met la direction possible pour s'éloigner
		if (agent != null) {
			float dx = a.getX() - agent.getX();
			float dy = a.getY() - agent.getY();

			int horizontalAction = (dx > 0) ? AgentAction.EAST : AgentAction.WEST;
			int verticalAction = (dy > 0) ? AgentAction.SOUTH : AgentAction.NORTH;

			// Choix de la meilleure direction en priorisant l'axe ayant le plus grand
			// déplacement
			int chosenAction = (Math.abs(dx) > Math.abs(dy)) ? horizontalAction : verticalAction;

			// Tentative de mouvement dans la direction choisie
			if (game.getMaze().isLegalMove(a, new AgentAction(chosenAction))) {
				a.moveOrder(new AgentAction(chosenAction));
			} else {
				// Si le mouvement n'est pas légal, essayer l'autre direction dans l'axe
				// priorisé
				int alternativeAction = (chosenAction == horizontalAction) ? verticalAction : horizontalAction;
				if (game.getMaze().isLegalMove(a, new AgentAction(alternativeAction))) {
					a.moveOrder(new AgentAction(alternativeAction));
				} else {
					// Si aucune direction n'est possible, choisir la direction opposée à la
					// première tentative
					int oppositeAction = (chosenAction + 2) % 4;
					if (game.getMaze().isLegalMove(a, new AgentAction(oppositeAction))) {
						a.moveOrder(new AgentAction(oppositeAction));

					}
					a.moveOrder(new AgentAction(oppositeAction));

				}
			}
		}

	}

}
