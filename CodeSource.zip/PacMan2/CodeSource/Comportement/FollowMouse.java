package Comportement;

import java.util.ArrayList;

import File.imageManager;
import Moteur.Agent;
import Moteur.AgentAction;
import Moteur.Maze;
import Moteur.PacMacGame;

public class FollowMouse extends Comportement {

	int Sx, Sy;

	int PosXP = -1, PosYP, FX = 1, FY = 1;
	ArrayList<Integer[]> path = new ArrayList<>();

	public FollowMouse(PacMacGame game) {
		super(game);
		Sx = new Maze(imageManager.getUrlcourante() + "Layouts/" + game.getMazeName()).getSizeX();
		Sy = new Maze(imageManager.getUrlcourante() + "Layouts/" + game.getMazeName()).getSizeY();
	}

	@Override
	public void move(Agent a) {
		PosXP = Math.round(a.getX());
		PosYP = Math.round(a.getY());

		if (path.isEmpty()) {
			if (!game.getMaze().isWall(FX, FY))
				path = AEtoile.CheminCourt(game.getMaze().getWalls(), PosXP, PosYP, FX, FY, Sx, Sy);

		} else {
			if (Math.round(a.getX()) > path.get(0)[0])
				a.moveOrder(new AgentAction(AgentAction.WEST));
			else if (Math.round(a.getX()) < path.get(0)[0])
				a.moveOrder(new AgentAction(AgentAction.EAST));
			else if (Math.round(a.getY()) > path.get(0)[1])
				a.moveOrder(new AgentAction(AgentAction.NORTH));
			else if (Math.round(a.getY()) < path.get(0)[1])
				a.moveOrder(new AgentAction(AgentAction.SOUTH));
			else
				path.remove(0);

		}

	}

	public void setArrival(int x, int y) {
		path.clear();
		FX = x;
		FY = y;

	}

	public int distance(int x1, int y1, int x2, int y2) {
		return Math.abs(x1 - x2) + Math.abs(y1 - y2);
	}

}
