package Comportement;

import java.util.ArrayList;
import java.util.Random;

import Moteur.Agent;
import Moteur.AgentAction;
import Moteur.Maze;
import Moteur.PacMacGame;

public class Aleatoire extends Comportement {

	int ancienX = -1, ancienY = -1;

	public Aleatoire(PacMacGame game) {
		super(game);

	}

	@Override
	public void move(Agent a) {

		if (!game.getMaze().isLegalMove(a, a.getAction()) || a.getAction().get_direction() == AgentAction.STOP) {
			a.moveOrder(getAction(a, game.getMaze()));
		}

	}

	public AgentAction getAction(Agent a, Maze maze) {
		ArrayList<AgentAction> actions = new ArrayList<>();

		actions.add(new AgentAction(AgentAction.NORTH));
		actions.add(new AgentAction(AgentAction.EAST));
		actions.add(new AgentAction(AgentAction.SOUTH));
		actions.add(new AgentAction(AgentAction.WEST));

		for (int i = 0; i < actions.size(); i++)
			if (!maze.isLegalMove(a, actions.get(i))) {
				actions.remove(i);
				i--;
			}
		return actions.get(new Random().nextInt(actions.size()));
		// return
		// actions.get((Math.round(a.getX())*Math.round(a.getY()))%actions.size());
	}
}
