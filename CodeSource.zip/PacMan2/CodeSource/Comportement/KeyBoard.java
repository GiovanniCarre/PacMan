package Comportement;

import Moteur.Agent;
import Moteur.AgentAction;
import Moteur.PacMacGame;

public class KeyBoard extends Comportement {

	private static int nbJoueur = 0;
	private int numeroJoueur = 0;

	public static void clear() {
		nbJoueur = 0;
	}

	public KeyBoard(PacMacGame game) {
		super(game);
		nbJoueur++;
		if (nbJoueur > 500) {
			System.err.println("Impossible d'avoir plus de 4 joueurs humains avec le clavier. Arrêt du programme");
			System.exit(0);
		}
		numeroJoueur = nbJoueur;
	}

	@Override
	public void move(Agent a) {
		if (Listener.Clavier.getInstance().touchePressed("joueur " + numeroJoueur + " haut")) {
			a.moveOrder(new AgentAction(AgentAction.NORTH));
		} else if (Listener.Clavier.getInstance().touchePressed("joueur " + numeroJoueur + " droite")) {
			a.moveOrder(new AgentAction(AgentAction.EAST));
		} else if (Listener.Clavier.getInstance().touchePressed("joueur " + numeroJoueur + " gauche")) {
			a.moveOrder(new AgentAction(AgentAction.WEST));
		} else if (Listener.Clavier.getInstance().touchePressed("joueur " + numeroJoueur + " bas")) {
			a.moveOrder(new AgentAction(AgentAction.SOUTH));
		}
	}

}
