package Comportement;

import java.util.ArrayList;
import java.util.Collections;

public class AEtoile {
	public static ArrayList<Integer[]> CheminCourt(boolean[][] map, int PosXP, int PosYP, int FX, int FY, int Sx,
			int Sy) {
		ArrayList<Node> openlist = new ArrayList<>();
		ArrayList<Node> closelist = new ArrayList<>();
		ArrayList<Integer[]> path = new ArrayList<>();

		if (map[FX][FY])
			map[FX][FY] = false;
		if (map[PosXP][PosYP])
			map[PosXP][PosYP] = false;
		Node node[][] = new Node[Sx][Sy];

		for (int x = 0; x < Sx; x++) {
			for (int y = 0; y < Sy; y++) {
				if (!map[x][y]) {
					node[x][y] = new Node(x, y, -5, -5);// -1 = no parents

				}
			}
		}

		openlist.add(new Node(PosXP, PosYP, -5, -5));
		while (openlist.size() > 0) {

			Node n = NodeLowQuality(openlist, openlist);
			if (n.x > 0) {
				if (!map[n.x - 1][n.y]) {
					if (!openlist.contains(node[n.x - 1][n.y]) && !closelist.contains(node[n.x - 1][n.y])) {
						InitializeNode(n, node[n.x - 1][n.y], FX, FY);
						openlist.add(node[n.x - 1][n.y]);

					}
				}

			}
			if (n.x < Sx - 1) {
				if (!map[n.x + 1][n.y]) {
					if (!openlist.contains(node[n.x + 1][n.y]) && !closelist.contains(node[n.x + 1][n.y])) {
						InitializeNode(n, node[n.x + 1][n.y], FX, FY);
						openlist.add(node[n.x + 1][n.y]);

					}
				}

			}
			if (n.y > 0) {
				if (!map[n.x][n.y - 1]) {
					if (!openlist.contains(node[n.x][n.y - 1]) && !closelist.contains(node[n.x][n.y - 1])) {
						InitializeNode(n, node[n.x][n.y - 1], FX, FY);
						openlist.add(node[n.x][n.y - 1]);

					}
				}
			}
			if (n.y < Sy - 1) {
				if (!map[n.x][n.y + 1]) {
					if (!openlist.contains(node[n.x][n.y + 1]) && !closelist.contains(node[n.x][n.y + 1])) {
						InitializeNode(n, node[n.x][n.y + 1], FX, FY);
						openlist.add(node[n.x][n.y + 1]);

					}
				}

			}
			if (n.x == FX && n.y == FY) {

				while (!(n.x == PosXP) || !(n.y == PosYP)) {
					Integer[] tab = { Integer.valueOf(n.x), Integer.valueOf(n.y) };
					path.add(tab);
					n = node[n.ParentsX][n.ParentsY];
				}
				Collections.reverse(path);

				break;
			}

			openlist.remove(n);
			closelist.add(n);

		}
		return path;

	}

	private static Node NodeLowQuality(ArrayList<Node> openlist, ArrayList<Node> openlist2) {
		int Vi = 0;
		float vmin = 1000;
		for (int i = 0; i < openlist2.size(); i++) {
			if (openlist2.get(i).Quality < vmin) {
				vmin = openlist.get(i).Quality;
				Vi = i;
			}
		}
		return openlist2.get(Vi);
	}

	public static int distance(int x1, int y1, int x2, int y2) {
		return Math.abs(x1 - x2) + Math.abs(y1 - y2);
	}

	private static void InitializeNode(Node parent, Node child, int FX, int FY) {

		child.ParentsX = parent.x;
		child.ParentsY = parent.y;

		child.Quality = Math.abs(child.x - FX + (child.y - FY));

	}
}
