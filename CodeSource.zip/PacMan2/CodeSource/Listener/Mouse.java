package Listener;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import Controller.ControllerPacmanGame;

public class Mouse implements MouseListener {

	private static Mouse instance;

	private ControllerPacmanGame controller;

	public static Mouse getInstance() {
		if (instance == null)
			instance = new Mouse();
		return instance;
	}

	private Mouse() {
	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (e.getButton() == 1)
			controller.leftClick();

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void setController(ControllerPacmanGame controller) {
		this.controller = controller;

	}

}
