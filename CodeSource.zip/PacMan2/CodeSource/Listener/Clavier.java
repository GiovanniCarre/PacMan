package Listener;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.swing.JOptionPane;

import Controller.ControllerPacmanGame;
import File.imageManager;
import Menu.Reglage;

public class Clavier implements KeyListener {

	private static Clavier instance;

	private ControllerPacmanGame controller;
	private static HashMap<Integer, String> touches = new HashMap<>();
	private static HashMap<String, Boolean> touchesPressed = new HashMap<>();

	public static Clavier getInstance() {
		if (instance == null)
			instance = new Clavier();
		return instance;
	}

	public static void setTouches(HashMap<Integer, String> touches) {

		Clavier.touches = touches;
		for (Entry<Integer, String> entry : touches.entrySet()) {
			touchesPressed.put(entry.getValue(), false);
		}
	}

	public void setController(ControllerPacmanGame controller) {
		this.controller = controller;
	}

	private Clavier() {
		try (ObjectInputStream objectInput = new ObjectInputStream(
				new FileInputStream(imageManager.getUrlcourante() + "Settings.settings"))) {

			Reglage r = (Reglage) objectInput.readObject();

			setTouches(r.getTouches());

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		setTouches(touches);

	}

	public boolean touchePressed(String id) {
		return touchesPressed.get(id);
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	public static HashMap<Integer, String> getTouches() {

		if (touches.isEmpty())
			getInstance();
		return touches;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (touches.containsKey(e.getExtendedKeyCode())) {

			if (touches.get(e.getExtendedKeyCode()).equals("pause")) {
				controller.pause();
				int choice = JOptionPane.showConfirmDialog(null, "Revenir au menu principal?");

				if (choice != 0)
					controller.play();
				else
					controller.stopGame();

			}
			touchesPressed.put(touches.get(e.getExtendedKeyCode()), true);
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (touches.containsKey(e.getExtendedKeyCode()))
			touchesPressed.put(touches.get(e.getExtendedKeyCode()), false);

	}

}
