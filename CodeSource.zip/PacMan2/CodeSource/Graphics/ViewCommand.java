package Graphics;

import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import Controller.AbstractController;
import Moteur.Game;
import Observer.Observer;
import StateButtonViewCommand.Etat;
import StateButtonViewCommand.PauseEtat;
import StateButtonViewCommand.PlayEtat;
import StateButtonViewCommand.RestartEtat;
import StateButtonViewCommand.StepEtat;

public class ViewCommand implements Observer {

	private JFrame frame;

	private JButton start, pause, restart, step;
	private JSlider slider;
	@SuppressWarnings("unused")
	private Etat state;
	private JLabel label;

	AbstractController controller;

	public ViewCommand(AbstractController controller) {
		this.controller = controller;

		// création de la fenêtre
		frame = new JFrame("Game");
		frame.setSize(1200, 1000);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension windowSize = frame.getSize();
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		Point centerPoint = ge.getCenterPoint();
		int dx = centerPoint.x - windowSize.width / 2;
		int dy = centerPoint.y - windowSize.height / 2 - 350;
		frame.setLocation(dx, dy);
		frame.setVisible(true);

		JPanel globalPanel = new JPanel(new GridLayout(2, 1));
		JPanel buttonPanel = new JPanel(new GridLayout(1, 4));
		JPanel sliderPanel = new JPanel(new GridLayout(1, 2));

		// création de l'interface graphique
		restart = new JButton(new ImageIcon("Ress/img/icon/restart.png"));
		restart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.restart();
				state = new RestartEtat(restart, start, step, pause);
				state.gerer();
			}
		});
		buttonPanel.add(restart);

		start = new JButton(new ImageIcon("Ress/img/icon/run.png"));
		start.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controller.play();
				state = new PlayEtat(restart, start, step, pause);
				state.gerer();
			}
		});
		buttonPanel.add(start);

		step = new JButton(new ImageIcon("Ress/img/icon/step.png"));
		step.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				state = new StepEtat(restart, start, step, pause);
				controller.step();
				state.gerer();
			}
		});
		buttonPanel.add(step);

		pause = new JButton(new ImageIcon("Ress/img/icon/pause.png"));
		buttonPanel.add(pause);
		pause.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				state = new PauseEtat(restart, start, step, pause);
				controller.pause();
				state.gerer();

			}
		});

		slider = new JSlider(1, 10);
		slider.setPaintTicks(true);
		slider.setMajorTickSpacing(1);
		slider.setPaintLabels(true);
		slider.setName("dsqdffdfq");
		slider.setToolTipText("fdgsd");
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				controller.setSpeed(slider.getValue());
			}
		});

		sliderPanel.add(slider);

		label = new JLabel("Turn : 0");
		frame.add(label);

		sliderPanel.add(label);

		globalPanel.add(buttonPanel);
		globalPanel.add(sliderPanel);

		state = new RestartEtat(restart, start, step, pause);
		state.gerer();

		frame.add(globalPanel);

		frame.repaint();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public void update(Game game) {
		label.setText("Tour : " + game.getTurn());

	}

}
