package Graphics;

import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Point;


import Observer.Observer;
import javax.swing.JFrame;
import javax.swing.JLabel;

import Moteur.Game;

public class ViewSimpleGame implements Observer{
	
	private JFrame frame;
	private JLabel label;
	
	public ViewSimpleGame() {
		frame = new JFrame("Game");
		frame.setSize(700,700);
		Dimension windowSize = frame.getSize();
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		Point centerPoint = ge.getCenterPoint();
		int dx = centerPoint.x - windowSize.width / 2;
		int dy = centerPoint.y + windowSize.height / 2+350;
		frame.setLocation(dx, dy);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		
		//création et ajout du label
		label = new JLabel("Tour numéro : 0", JLabel.CENTER);
		frame.add(label);
		label.repaint();
		
	}

	public void update(Game game) {
		label.setText("Tour numéro : "+game.getTurn());
	}
}
