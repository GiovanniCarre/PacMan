package Graphics;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.ArrayList;

import javax.swing.JPanel;

import File.imageManager;
import Moteur.Agent;
import Moteur.PacMacGame;
import Moteur.PacMan;

public class PanelPacMan extends JPanel {

	private static final long serialVersionUID = 1L;

	private Color wallColor = Color.BLUE;

	private PacMacGame game;

	private static PanelPacMan instance = null;

	private static int sizeX;
	private static int sizeY;
	private static String pictureToPrint = null;

	public static PanelPacMan getInstance() {
		if (instance == null)
			instance = new PanelPacMan();
		return instance;
	}

	private PanelPacMan() {
	}

	public static int getSizeX() {
		return sizeX;
	}

	public static int getSizeY() {
		return sizeY;
	}

	public int getSizeXPanel() {
		return getWidth();
	}

	public int getSizeYPanel() {
		return getHeight();
	}

	public void paint(Graphics graphics) {

		Graphics2D g = (Graphics2D) graphics;

		int dx = getWidth();
		int dy = getHeight();
		g.setColor(Color.black);
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		g.fillRect(0, 0, dx, dy);

		if (pictureToPrint == null) {

			int sx = game.getMaze().getSizeX();
			int sy = game.getMaze().getSizeY();

			sizeX = getWidth() / sx;
			sizeY = getHeight() / sy;

			for (int x = 0; x < sx; x++) {
				for (int y = 0; y < sy; y++) {
					if (game.getMaze().isWall(x, y)) {
						g.setColor(wallColor);
						g.fillRect(x * sizeX, y * sizeY, sizeX, sizeY);
					}
					if (game.getMaze().isFood(x, y)) {
						g.drawImage(imageManager.getImageIcon("cherry").getImage(), x * sizeX, y * sizeY, sizeX, sizeY,
								null);

					}
					if (game.getMaze().isCapsule(x, y)) {
						g.drawImage(imageManager.getImageIcon("soda").getImage(), x * sizeX, y * sizeY, sizeX, sizeY,
								null);
					}
				}

			}
			for (int i = 0; i < game.getAgents().size(); i++) {
				Agent a = game.getAgents().get(i);
				g.drawImage(imageManager.getImageIcon("Personnage/" + a.getSprite()).getImage(),
						(int) (a.getX() * sizeX), (int) (a.getY() * sizeY), sizeX, sizeY, null);

			}

			// affichage des coeurs
			ArrayList<Integer> coeurs = new ArrayList<>();
			for (int i = 0; coeurs.size() < 4 && i < game.getAgents().size(); i++) {
				if (game.getAgents().get(i) instanceof PacMan) {
					coeurs.add(((PacMan) game.getAgents().get(i)).getLife());
				}
			}

			int startX, startY;
			g.setColor(Color.black);
			g.setFont(new Font("Gabriela", Font.BOLD, getWidth() / (sx * 3)));
			for (int i = 0; i < coeurs.size(); i++) {
				if (i == 0) {
					startX = 0;
					startY = 0;
				} else if (i == 1) {
					startX = sx - PacMan.getLifemax() - 2;
					startY = 0;
				} else if (i == 2) {
					startX = 0;
					startY = sy - 1;
				} else {
					startX = sx - PacMan.getLifemax() - 2;
					startY = sy - 1;
				}
				for (int j = 1; j <= coeurs.get(i); j++)
					g.drawImage(imageManager.getImageIcon("heart").getImage(), startX * sizeX + j * sizeX,
							startY * sizeY, sizeX, sizeY, null);

				for (int j = coeurs.get(i) + 1; j <= PacMan.getLifemax(); j++)
					g.drawImage(imageManager.getImageIcon("heart2").getImage(), startX * sizeX + j * sizeX,
							startY * sizeY, sizeX, sizeY, null);
				if (i == 0)
					g.drawString("J" + (i + 1), sizeX / 2, sizeY / 2);
				if (i == 1)
					g.drawString("J" + (i + 1), sx * sizeX - sizeX / 2, sizeY / 2);
				if (i == 2)
					g.drawString("J" + (i + 1), sizeX / 2, sy * sizeY - sizeY / 2);
				if (i == 3)
					g.drawString("J" + (i + 1), sx * sizeX - sizeX / 2, sy * sizeY - sizeY / 2);
			}
			g.drawString("Score : " + game.getScoreTotal(), sx / 2 * sizeX, sizeY / 2);

		} else
			g.drawImage(imageManager.getImageIcon(pictureToPrint).getImage(), 0, 0, dx, dy, null);

	}

	public void refresh(PacMacGame game) {
		this.game = game;
		repaint();
	}

	public static void setPictureToPrint(String pictureToPrint) {
		PanelPacMan.pictureToPrint = pictureToPrint;
	}

}
