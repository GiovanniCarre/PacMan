package Graphics;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;

import Controller.ControllerPacmanGame;
import File.imageManager;
import Listener.Clavier;
import Listener.Mouse;
import Moteur.Game;
import Moteur.PacMacGame;
import Observer.Observer;

public class ViewPacmanGame implements Observer {

	JFrame frame;

	PanelPacMan panel;

	public ViewPacmanGame(PacMacGame game, ControllerPacmanGame controller) {
		frame = new JFrame(imageManager.urlCourante);

		int largeurGrille = game.getMaze().getSizeX();
		int hauteurGrille = game.getMaze().getSizeY();

		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Dimension screenSize = toolkit.getScreenSize();

		int largeurMax = (int) (screenSize.width / largeurGrille) * largeurGrille;
		int hauteurMax = (int) (screenSize.height / hauteurGrille) * hauteurGrille;

		frame.setSize(largeurMax, hauteurMax);

		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		try {
			panel = PanelPacMan.getInstance();
			panel.refresh(game);
		} catch (Exception e) {
			e.printStackTrace();
		}
		frame.setContentPane(panel);
		Clavier.getInstance().setController(controller);
		
		frame.addKeyListener(Clavier.getInstance());
		Mouse.getInstance().setController(controller);
		frame.addMouseListener(Mouse.getInstance());

	}

	@Override
	public void update(Game g) {
		PacMacGame game = (PacMacGame) g;

		if (game.isDestroyed())
			frame.dispose();

		panel.refresh(game);

	}

}
