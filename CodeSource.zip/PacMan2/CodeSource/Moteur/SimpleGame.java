package Moteur;

import Controller.ControllerSimpleGame;
import Graphics.ViewCommand;
import Graphics.ViewSimpleGame;

public class SimpleGame extends Game{

	public SimpleGame(long runTime) {
		super(runTime);
		om.addObserver(new ViewSimpleGame());
		om.addObserver(new ViewCommand(new ControllerSimpleGame(this)));
	}

	@Override
	protected void initializeGame() {
		
	}

	@Override
	protected void gameOver() {
		
	}

	@Override
	protected void takeTurn() {
		
	}

	@Override
	protected boolean gameContinue() {
		return true;
	}

}
