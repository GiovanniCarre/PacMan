package Moteur;

import Observer.ObserverManager;

public abstract class Game implements Runnable {

	protected int turn = 0;

	private final int maxTurn = Integer.MAX_VALUE;
	private boolean isRunning = false;
	protected long runTime;

	private Thread thread;

	protected ObserverManager om;

	public Game(long runTime) {
		this.runTime = runTime;
		om = new ObserverManager();
		om.setGame(this);

	}

	public void launch() {

		isRunning = true;
		thread = new Thread(this);
		thread.start();
	}

	public void init() {
		turn = 0;
		isRunning = true;
		initializeGame();
	}

	protected abstract void initializeGame();

	public void step() {
		turn++;
		if (gameContinue() && turn <= maxTurn) {

			takeTurn();
		} else {
			gameOver();
			isRunning = false;

		}
		notifyObservers();
	}

	protected abstract void gameOver();

	protected abstract void takeTurn();

	protected abstract boolean gameContinue();

	public void pause() {
		isRunning = false;
	}

	public void run() {
		long maxTime = -1;

		long startTime = System.currentTimeMillis();
		while (isRunning) {

			step();
			long endTime = System.currentTimeMillis();
			long elapsedTime = endTime - startTime;
			if (maxTime < elapsedTime)
				maxTime = elapsedTime;

			try {
				Thread.sleep(Math.max(0, runTime - elapsedTime));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			startTime = System.currentTimeMillis();
		}
		long endTime = System.currentTimeMillis();
		// le temps écoulé
		@SuppressWarnings("unused")
		long elapsedTime = endTime - startTime;

	}

	public void notifyObservers() {
		om.notifyObservers();
	}

	public int getTurn() {
		return turn;
	}

	public void setSpeed(double speed) {
		runTime = (long) (1000 / speed);
	}
}
