package Moteur;

import Animation.State;
import Comportement.Comportement;

public class PacMan extends Agent {

	private final static int lifeMax = 1;
	private int score = 0;
	private int _life;

	public PacMan(Comportement moveStrategy, PositionAgent position, PacMacGame game) {
		super(moveStrategy, position, game);
		_life = lifeMax;
	}

	public boolean isDead() {
		return _life <= 0;
	}

	public static int getLifemax() {
		return lifeMax;
	}

	public void move(int ticks) {
		super.move(ticks);
		if (game.getMaze().isFood((int) (getX() + 0.5f), (int) (getY() + 0.5f))) {
			addScore(POINTS_EAT_CAPSULE);
			game.getMaze().setFood((int) (getX() + 0.5f), (int) (getY() + 0.5f), false);
		}
		if (game.getMaze().isCapsule((int) (getX() + 0.5f), (int) (getY() + 0.5f))) {
			game.haveEatFruit();
			addScore(POINTS_EAT_SODA);
			game.getMaze().setCapsule((int) (getX() + 0.5f), (int) (getY() + 0.5f), false);
		}
		if (timeLeftKnockOut != 0) {
			if (timeLeftKnockOut == 1)
				setState(State.Walk);

			timeLeftKnockOut--;
		}

	}

	@Override
	protected void kill(int ticks) {
		if (getState() != State.KnockOut) {
			addScore(POINTS_EAT_PACMAN);
			setState(State.KnockOut);
			timeLeftKnockOut = ticks * 10;
			_life--;
		}
	}

	public int getLife() {
		return _life;
	}

	public int getScore() {
		return score;
	}

	public void addScore(int points) {
		game.addScore(points);
		score += points;
	}

}
