package Moteur;

import java.io.Serializable;

public class PositionAgent implements Serializable {

	private static final long serialVersionUID = 1L;

	private float x;
	private float y;
	private int dir;

	public PositionAgent(int x, int y, int dir) {
		this.x = x;
		this.y = y;
		this.dir = dir;
	}

	public float getX() {
		return x;
	}
	
	public int getRealX() {
		return (int)x;
	}
	
	public int getRealY() {
		return (int)y;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public int getDir() {
		return dir;
	}

	public void setDir(int dir) {
		this.dir = dir;
	}

	public String toString() {
		return "(" + x + "," + y + ")";
	}
	
	public boolean equals(PositionAgent other) {
		return (x == other.x) && (y == other.y);
	}
	
	public String directionToString() {
		if (dir == AgentAction.WEST)
			return "l";
		else if (dir == AgentAction.NORTH)
			return "u";
		else if (dir == AgentAction.EAST)
			return "r";
		return "d";
	}

}
