package Moteur;

import Animation.AnimationData;
import Animation.AnimationManager;
import Animation.State;
import Comportement.Comportement;

public abstract class Agent {
	protected Comportement comportement;
	protected PositionAgent position;
	protected AgentAction action = new AgentAction(4);
	protected PacMacGame game;
	protected int timeLeftKnockOut;
	
	
	protected final static int POINTS_EAT_GHOSTS = 5;
	protected final static int POINTS_EAT_PACMAN = -10;
	protected final static int POINTS_EAT_CAPSULE = 1;
	protected final static int POINTS_EAT_SODA = 3;

	// animation
	protected int animationNumber;
	protected int animationTime;
	private State state;
	protected String sprite;

	public Agent(Comportement moveStrategy, PositionAgent position, PacMacGame game) {
		this.comportement = moveStrategy;
		this.position = position;
		this.game = game;
		state = State.Walk;
		sprite = this.getClass().getSimpleName() + state.name() + "1" + position.directionToString();
		animationNumber = AnimationData.getNumberAnim().get(this.getClass().getSimpleName() + state.name());
		animationTime = AnimationData.getTimeAnim().get(this.getClass().getSimpleName() + state.name());
	}

	public PositionAgent getPosition() {
		return position;
	}

	
	public int getAnimationNumber() {
		return animationNumber;
	}

	public int getAnimationTime() {
		return animationTime;
	}

	public AgentAction getAction() {
		return action;
	}

	public State getState() {
		return state;
	}

	public boolean isDead() {
		return false;
	}

	public String getSprite() {
		return sprite;
	}

	public Comportement getComportement() {
		return comportement;
	}

	public float getX() {
		return position.getX();
	}

	public float getY() {
		return position.getY();
	}

	public void setAction(AgentAction action) {
		this.action = action;
	}

	public void move(int ticks) {
		// comportement permet de définir la nouvelle action
		comportement.move(this);
		AnimationManager.work(this);

		// permet d'appliquer l'action si elle est légale
		if (game.getMaze().isLegalMove(this, action))
			if (action.get_vx() == 0) {
				addY((float) action.get_vy() / ticks);
				position.setX(Math.round(position.getX()));
			} else if (action.get_vx() != 0) {
				addX((float) action.get_vx() / ticks);
				position.setY(Math.round(position.getY()));
			}

	}

	public void addX(float f) {
		position.setX(position.getX() + f);
	}

	public void addY(float f) {
		position.setY(position.getY() + f);
	}

	// est appelé par un comportement pour donner une action
	public void moveOrder(AgentAction agentAction) {
		if (game.getMaze().isLegalMove(this, agentAction)) {

			action = agentAction;
			position.setDir(action.get_direction());
			if (game.getMaze().isFood(0, 0))
				game.getMaze().setFood(0, 0, false);
		}
	}

	public void incAnimationTime() {
		animationTime++;
	}

	public void resetAnimationTime() {
		animationTime = 0;
	}

	public void setState(State state) {
		this.state = state;
		animationNumber = 0;
		animationTime = 0;
		AnimationManager.work(this);
	}

	public void incAnimationNumber() {
		animationNumber++;
	}

	public void setSprite(String sprite) {
		this.sprite = sprite;
	}

	public void resetAnimationNumber() {
		animationNumber = 1;
	}

	protected void kill(int ticks) {
		setState(State.KnockOut);
	}

}
