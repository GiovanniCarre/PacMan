package Moteur;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import Animation.AnimationData;
import Animation.State;
import Comportement.KeyBoard;
import Controller.ControllerPacmanGame;
import Fabrique.FabriqueAgent;
import File.imageManager;
import Graphics.PanelPacMan;
import Graphics.ViewPacmanGame;
import Listener.Clavier;
import Menu.Configuration;
import Menu.MenuManager;
import Menu.Reglage;

public class PacMacGame extends Game {

	private static PacMacGame instance;
	private static boolean stop = false;

	private boolean destroyed = false;
	private Maze maze;
	private Configuration configuration;
	private String mazeName;
	private ArrayList<Agent> agents = new ArrayList<>();
	private boolean ghostsScarred = false;
	private int turnEated = 0;
	private FabriqueAgent fabrique;
	private int ScoreTotal = 0;

	private final int ticks = 60;

	public static PacMacGame getInstance() {
		return instance;
	}

	public static void createNewGame(String mazeName, Configuration c) {
		Reglage r = null;
		try (ObjectInputStream entreeObjet = new ObjectInputStream(
				new FileInputStream(imageManager.getUrlcourante() + "Settings.settings"))) {
			r = (Reglage) entreeObjet.readObject();
			
			Clavier.setTouches(r.getTouches());
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}

		instance = new PacMacGame(1000 / r.getFps(), mazeName, c);

	}

	private PacMacGame(long runTime, String mazeName, Configuration c) {
		super(runTime);
		this.mazeName = mazeName;
		this.configuration = c;
		AnimationData.initialize();

	}

	public void setDestroyed(boolean destroyed) {
		this.destroyed = destroyed;
	}

	public boolean isDestroyed() {
		return destroyed;
	}

	public static boolean isStop() {
		return stop;
	}

	@Override
	protected void initializeGame() {
		turnEated = 0;
		KeyBoard.clear();
		agents.clear();
		try {
			fabrique = new FabriqueAgent((Configuration) configuration.clone());
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		try {
			this.maze = new Maze(imageManager.getUrlcourante() + "Layouts/" + mazeName, configuration, this);
		} catch (Exception e) {
			e.printStackTrace();
		}
		PanelPacMan.setPictureToPrint(null);

		stop = false;

		om.addObserver(new ViewPacmanGame(this, new ControllerPacmanGame(this)));

	}

	@Override
	protected void gameOver() {
		stop = true;
		if (stayFruit())
			PanelPacMan.setPictureToPrint("defaite");
		else
			PanelPacMan.setPictureToPrint("victoire");
		PanelPacMan.getInstance().repaint();

	}

	public boolean isGhostsScarred() {
		return ghostsScarred;
	}

	@Override
	protected void takeTurn() {
		// permet d'enlever les effets de peur chez les fantômes
		if (ghostsScarred && turn > 20 * ticks + turnEated) {
			ghostsScarred = false;
			for (int i = 0; i < agents.size(); i++) {
				if (agents.get(i) instanceof Fantome && agents.get(i).getState() == State.Affraid) {
					agents.get(i).setState(State.Walk);
				}
			}
		}

		for (int i = 0; i < agents.size(); i++)
			agents.get(i).move(ticks);

		for (int i = agents.size() - 1; i >= 0; i--)
			if (agents.get(i).isDead())
				agents.remove(i);

	}

	@Override
	protected boolean gameContinue() {
		return stayFruit() && stayPacMan() && !stop;
	}

	private boolean stayFruit() {
		for (int x = 0; x < maze.getSizeX(); x++)
			for (int y = 0; y < maze.getSizeY(); y++)
				if (maze.isFood(x, y))
					return true;

		return false;
	}
	
	public int getScoreTotal() {
		return ScoreTotal;
	}

	private boolean stayPacMan() {
		for (int i = 0; i < agents.size(); i++)
			if (agents.get(i) instanceof PacMan)
				return true;
		return false;
	}

	public ArrayList<Agent> getAgents() {
		return agents;
	}

	public Maze getMaze() {
		return maze;
	}
	
	public String getMazeName() {
		return mazeName;
	}

	public void haveEatFruit() {
		turnEated = turn;
		ghostsScarred = true;
		for (int i = 0; i < agents.size(); i++) {
			if (agents.get(i) instanceof Fantome && ((Fantome) agents.get(i)).getState() != State.KnockOut)
				agents.get(i).setState(State.Affraid);
		}
	}

	public float getTicks() {
		return ticks;
	}

	public int havePacManAt(float x, float y) {
		for (int i = 0; i < agents.size(); i++)
			if (agents.get(i) instanceof PacMan
					&& collisionSquare(x, y, 1f, 1f, agents.get(i).getX(), agents.get(i).getY(), 1f, 1f))
				return i;
		return -1;
	}

	public static boolean collisionSquare(float x1, float y1, float sizeX1, float sizeY1, float x2, float y2,
			float sizeX2, float sizeY2) {
		return (x1 + sizeX1 >= x2 && x2 + sizeX2 >= x1) && (y1 + sizeY1 >= y2 && y2 + sizeY2 >= y1);
	}

	public void reset() {
		stop = true;
		try {
			Thread.sleep(ticks * 3);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		turnEated = 0;
		KeyBoard.clear();
		agents.clear();
		destroyed = true;
		notifyObservers();
		stop = false;

		om = null;
		createNewGame(mazeName, configuration);
		instance.init();
		instance.launch();

	}

	public void ajouterAgent(String string, int x, int y, Configuration c) {
		agents.add(fabrique.creerUnite(string, x, y, this));
	}

	public static void stop() {
		getInstance().setDestroyed(true);
		stop = true;
		PacMacGame.getInstance().notifyObservers();
		MenuManager.getInstance().init();
	}

	public void addScore(int points) {
		ScoreTotal+=points;
	}

}
