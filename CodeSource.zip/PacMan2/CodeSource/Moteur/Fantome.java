package Moteur;

import Animation.AnimationManager;
import Animation.State;
import Comportement.Comportement;

public class Fantome extends Agent {

	private final PositionAgent startPosition;

	public Fantome(Comportement moveStrategy, PositionAgent position, PacMacGame game) {
		super(moveStrategy, position, game);

		startPosition = new PositionAgent(position.getRealX(), position.getRealY(), 0);
	}

	@Override
	public void move(int ticks) {
		if (getState() != State.KnockOut) {
			super.move(ticks);
			int pac = game.havePacManAt(getX(), getY());
			if (game.havePacManAt(getX(), getY()) != -1) {
				if (getState() == State.Affraid) {
					kill(ticks);
					((PacMan) game.getAgents().get(pac)).addScore(POINTS_EAT_GHOSTS);
				} else {
					if (game.getAgents().get(pac).getState() != State.KnockOut)
						kill(ticks);
					game.getAgents().get(pac).kill(ticks);

				}

			}
		} else if (timeLeftKnockOut < 0)
			setState(State.Walk);
		else {
			AnimationManager.work(this);
			timeLeftKnockOut--;
		}

	}

	@Override
	protected void kill(int ticks) {
		super.kill(ticks);
		AnimationManager.work(this);
		position = new PositionAgent(startPosition.getRealX(), startPosition.getRealY(), 0);
		timeLeftKnockOut = ticks * 10;

	}

}