package Exception;

@SuppressWarnings("serial")
public class ExceptionCustom extends Exception {
    public ExceptionCustom(String message) {
        super(message);
    }
}
