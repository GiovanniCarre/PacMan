package Menu;

import java.util.ArrayList;

public class Configuration implements Cloneable {

	private String comportementGhost;
	private String comportementPacMan;

	private ArrayList<String> rolePlayers;

	public Configuration(String comportementGhost, String comportementPacMan, ArrayList<String> rolePlayers) {
		super();
		this.comportementGhost = comportementGhost;
		this.comportementPacMan = comportementPacMan;
		this.rolePlayers = rolePlayers;
	}

	public String getComportementPacMan() {
		return comportementPacMan;
	}

	public String getComportementGhost() {
		return comportementGhost;
	}

	public ArrayList<String> getRolePlayers() {
		return rolePlayers;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		ArrayList<String> buffer = new ArrayList<>();
		for (int i = 0; i < rolePlayers.size(); i++)
			buffer.add(rolePlayers.get(i));

		return new Configuration(comportementGhost, comportementPacMan, buffer);
	}
}
