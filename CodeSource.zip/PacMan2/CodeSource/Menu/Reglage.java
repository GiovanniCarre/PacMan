package Menu;

import java.io.Serializable;
import java.util.HashMap;

@SuppressWarnings("serial")
public class Reglage implements Serializable {
	private int fps;
	private int musicVolum;
	private boolean antiAliasing;
	private int soundVolum;
	// Controls
	private HashMap<Integer, String> touches = new HashMap<>();

	public Reglage(int fps, int musicVolum, boolean antiAliasing, int soundVolum, HashMap<Integer, String> touches) {
		this.fps = fps;
		this.musicVolum = musicVolum;
		this.antiAliasing = antiAliasing;
		this.soundVolum = soundVolum;
		this.touches = touches;
	}

	
	public int getFps() {
		return fps;
	}
	
	public int getMusicVolum() {
		return musicVolum;
	}
	
	public int getSoundVolum() {
		return soundVolum;
	}
	public HashMap<Integer, String> getTouches() {
		return touches;
	}
	public boolean isAntiAliasing() {
		return antiAliasing;
	}
}
