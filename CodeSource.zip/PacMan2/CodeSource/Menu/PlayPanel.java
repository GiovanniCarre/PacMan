package Menu;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;

import Exception.ExceptionCustom;
import File.imageManager;
import Moteur.Maze;
import Moteur.PacMacGame;

@SuppressWarnings("serial")
public class PlayPanel extends PanelCustom {

	private ButtonCustom play = new ButtonCustom("Play");
	private ButtonCustom mainMenu = new ButtonCustom("Main Menu");
	private Maze maze = null;
	private String mazeName = null;
	private ArrayList<ButtonMap> carte = new ArrayList<>();
	private int selectedCarte = 0;
	private ButtonImage previousButton = new ButtonImage("left");
	private ButtonImage nextButton = new ButtonImage("right");

	private ArrayList<JLabel> choicePlayerLabel = new ArrayList<>();
	private ArrayList<JComboBox<String>> choicePlayer = new ArrayList<>();

	private JComboBox<String> iaFantome, iaPacMan;

	@Override
	protected void paintComponent(Graphics g) {

		g.setColor(Color.white);
		g.fillRect(0, 0, getWidth(), getHeight());

		g.setColor(Color.blue);
		g.fillRect(getWidth() / 3 * 2, getHeight() / 8, getWidth() / 5, getHeight() / 5);

		if (maze != null) {
			int sizeX = getWidth() / 5 / maze.getSizeX(), sizeY = getHeight() / 5 / maze.getSizeY();
			for (int x = 0; x < maze.getSizeX(); x++)
				for (int y = 0; y < maze.getSizeY(); y++) {
					if (maze.isWall(x, y))
						g.setColor(Color.blue);
					else
						g.setColor(Color.black);
					g.fillRect(getWidth() / 3 * 2 + x * sizeX, getHeight() / 8 + y * sizeY, sizeX, sizeY);
				}
			g.setColor(Color.black);
			g.setFont(new Font("Gabriela", Font.BOLD, getHeight() / 30));
			g.drawString(mazeName, getWidth() / 3 * 2, getHeight() / 5 * 2);
			g.drawImage(imageManager.getImageIcon("Personnage/FantomeWalk1r").getImage(), getWidth() / 10 * 8,
					getHeight() / 100 * 48, getWidth() / 10, getHeight() / 10, null);

			g.drawImage(imageManager.getImageIcon("Personnage/PacManWalk1r").getImage(), getWidth() / 10 * 8,
					getHeight() / 4 * 3, getWidth() / 10, getHeight() / 10, null);
		}
	}

	void update() {
		int w = getWidth(), h = getHeight();
		mainMenu.setFont(MenuManager.getButtonFont());
		mainMenu.setSize(w / 4, h / 15);

		mainMenu.setLocation(w / 5, h / 10 * 9);
		play.setFont(MenuManager.getButtonFont());
		play.setSize(w / 4, h / 15);
		play.setLocation(w - w / 4 - w / 5, h / 10 * 9);

		for (int i = 0; i < carte.size(); i++) {

			if (selectedCarte <= i && i < selectedCarte + 6) {
				carte.get(i).setFont(MenuManager.getButtonFont());
				carte.get(i).setBounds(w / 20, (i - selectedCarte) * h / 10 + h / 5, w / 5 * 2, h / 10);
			} else
				carte.get(i).setBounds(0, 0, 0, 0);
		}

		previousButton.setBounds(w / 20, h / 12, w / 10, h / 10);
		nextButton.setBounds(w / 20 + w / 5 * 2 - w / 10, h / 12, w / 10, h / 10);

		for (int i = 0; i < choicePlayer.size(); i++) {
			choicePlayerLabel.get(i).setVisible(mazeName != null);
			choicePlayer.get(i).setVisible(mazeName != null);

			choicePlayerLabel.get(i).setFont(MenuManager.getButtonFont());
			choicePlayerLabel.get(i).setBounds(w / 2, h / 20 * 8 + i * h / 8, w / 5, h / 20);
			choicePlayer.get(i).setFont(MenuManager.getButtonFont());
			choicePlayer.get(i).setBounds(w / 2, h / 20 * 9 + i * h / 8, w / 5, h / 20);
		}

		iaPacMan.setVisible(mazeName != null);
		iaFantome.setVisible(mazeName != null);
		iaPacMan.setFont(MenuManager.getButtonFont());
		iaFantome.setFont(MenuManager.getButtonFont());
		iaFantome.setBounds(w / 20 * 18, h / 50 * 24, w / 10, h / 10);
		iaPacMan.setBounds(w / 20 * 18, h / 20 * 15, w / 10, h / 10);

		repaint();

	}

	void init() {
		String options1[] = { "IA Aléatoire", "A* sur les Pac-Man", "suit la souris" , "Fuire les pac-Man"};
		iaFantome = new JComboBox<String>(options1);
		add(iaFantome);

		String options2[] = { "IA Aléatoire", "A sur les fruits", "suit la souris" ,"Fuire les pac-Man"};
		iaPacMan = new JComboBox<String>(options2);
		add(iaPacMan);

		String[] options = { "Ne joue pas", "Fantome", "Pac-Man"};
		choicePlayer.add(new JComboBox<String>(options));
		choicePlayer.add(new JComboBox<String>(options));
		choicePlayer.add(new JComboBox<String>(options));
		choicePlayer.add(new JComboBox<String>(options));

		choicePlayerLabel.add(new JLabel("Joueur 1"));
		choicePlayerLabel.add(new JLabel("Joueur 2"));
		choicePlayerLabel.add(new JLabel("Joueur 3"));
		choicePlayerLabel.add(new JLabel("Joueur 4"));

		setLayout(null);
		File f = new File(imageManager.getUrlcourante() + "Layouts");
		try {
			if (!f.exists() || !f.isDirectory())
				throw new ExceptionCustom("Dossier Layouts introuvable");
		} catch (ExceptionCustom e) {
			e.printStackTrace();
		}

		File[] fichiers = f.listFiles();

		if (fichiers != null)
			for (File fichier : fichiers)
				if (fichier.isFile())
					carte.add(new ButtonMap(fichier.getName(), this, carte.size() - 1));

		mainMenu.addActionListener(new MainMenuListener());
		add(mainMenu);
		add(play);
		nextButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (selectedCarte < carte.size() - 5) {
					selectedCarte += 6;
					update();
				}
			}
		});
		add(nextButton);
		previousButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (selectedCarte > 0) {
					selectedCarte -= 6;
					update();
				}

			}
		});

		add(previousButton);

		for (int i = 0; i < carte.size(); i++) {
			add(carte.get(i));
			carte.get(i).addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					ButtonMap source = (ButtonMap) e.getSource();
					changeSelection(source.getText(), source.getMaze());
					update();
				}
			});
		}

		for (int i = 0; i < choicePlayer.size(); i++) {
			add(choicePlayer.get(i));
			add(choicePlayerLabel.get(i));
		}

		play.addActionListener(new StartGameAction(this));

	}

	void changeSelection(String mazeName, Maze maze) {
		this.maze = maze;
		this.mazeName = mazeName;
	}

	public String getMazeName() {
		return mazeName;
	}

	public ArrayList<JComboBox<String>> getChoicePlayer() {
		return choicePlayer;
	}

	public JComboBox<String> getIaFantome() {
		return iaFantome;
	}

	public JComboBox<String> getIaPacMan() {
		return iaPacMan;
	}

}

@SuppressWarnings("serial")
class ButtonMap extends JButton {

	private Maze maze;
	@SuppressWarnings("unused")
	private PlayPanel panel;

	public ButtonMap(String name, PlayPanel panel, int i) {
		super(name);

		this.panel = panel;
		try {
			maze = new Maze(imageManager.getUrlcourante() + "Layouts/" + name);
		} catch (Exception e) {
			e.printStackTrace();
		}

		addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				panel.changeSelection(name, maze);
			}
		});
	}

	public Maze getMaze() {
		return maze;
	}

	@Override
	protected void paintComponent(Graphics g) {
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(0, 0, getWidth(), getHeight());
		g.setColor(Color.black);
		Font f = new Font("Gabriela", Font.BOLD, getHeight() / 5);
		g.setFont(f);
		if (getText().split(".lay").length == 0) {
			g.drawString("Fichier non valide : " + getText(), 0, getHeight() / 2);
		} else {
			g.setFont(f);
			g.drawString(getText().split(".lay")[0].substring(0, Math.min(22, getText().split(".lay")[0].length())), 0,
					getHeight() / 5 * 2);

			g.setFont(new Font("Gabriela", Font.PLAIN, getHeight() / 5));
			g.drawString(maze.getSizeX() + "x" + maze.getSizeY(), getWidth() / 20, getHeight() / 10 * 8);
			g.setFont(f);

			// nb Pacman
			g.drawImage(imageManager.getImageIcon("Personnage/PacManWalk1r").getImage(), getWidth() / 5 * 2,
					getHeight() / 10, getWidth() / 6, getHeight() / 10 * 8, null);
			g.drawString(String.valueOf(maze.getPacman_start().size()), getWidth() / 10 * 6, getHeight() / 2);

			// nbFantome
			g.drawImage(imageManager.getImageIcon("Personnage/FantomeAffraid1r").getImage(), getWidth() / 10 * 7,
					getHeight() / 10, getWidth() / 6, getHeight() / 10 * 8, null);
			g.drawString(String.valueOf(maze.getGhosts_start().size()), getWidth() / 10 * 9, getHeight() / 2);

		}

	}

}

class MainMenuListener implements ActionListener {
	@Override
	public void actionPerformed(ActionEvent e) {
		MenuManager.getInstance().setPanel(new mainMenuPanel());
	}
}

@SuppressWarnings("serial")
class ButtonImage extends JButton {

	private final ImageIcon image;

	public ButtonImage(String s) {
		super();
		image = imageManager.getImageIcon(s);
	}

	@Override
	public void paint(Graphics g) {
		g.drawImage(image.getImage(), 0, 0, getWidth(), getHeight(), null);
		g.setColor(Color.black);
		g.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
	}

}

class StartGameAction implements ActionListener {

	private final PlayPanel panel;

	public StartGameAction(PlayPanel playPanel) {
		panel = playPanel;
	}

	public void actionPerformed(ActionEvent e) {

		ArrayList<String> rolePlayers = new ArrayList<String>();
		for (int i = 0; i < panel.getChoicePlayer().size(); i++)
			rolePlayers.add((String) panel.getChoicePlayer().get(i).getSelectedItem());

		Configuration c = new Configuration((String) panel.getIaFantome().getSelectedItem(),
				(String) panel.getIaPacMan().getSelectedItem(), rolePlayers);
		
		
		PacMacGame.createNewGame(panel.getMazeName(), c);

		PacMacGame.getInstance().init();
		PacMacGame.getInstance().launch();
		MenuManager.getInstance().dispose();
	}
}