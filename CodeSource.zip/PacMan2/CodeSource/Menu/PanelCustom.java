package Menu;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public abstract class PanelCustom extends JPanel {

	abstract void init();
	abstract void update();
}
