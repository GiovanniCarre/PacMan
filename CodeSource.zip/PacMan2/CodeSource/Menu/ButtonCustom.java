package Menu;

import java.awt.Color;

import javax.swing.JButton;

@SuppressWarnings("serial")
public class ButtonCustom extends JButton {

	public ButtonCustom(String s) {
		super(s);
		setBackground(Color.DARK_GRAY);
		setForeground(Color.white);

	}

}