package Menu;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import File.imageManager;

@SuppressWarnings("serial")
public class mainMenuPanel extends PanelCustom {

	ArrayList<ButtonCustom> mainButton = new ArrayList<>();

	@Override
	void init() {

		setLayout(null);

		mainButton.add(new ButtonCustom("Play"));
		mainButton.add(new ButtonCustom("Settings"));
		mainButton.add(new ButtonCustom("Leave"));

		for (int i = 0; i < mainButton.size(); i++) 
			add(mainButton.get(i));
		

		mainButton.get(0).addActionListener(new PlayAction());
		mainButton.get(1).addActionListener(new SettingsAction());
		mainButton.get(2).addActionListener(new LeaveAction());

	}

	@Override
	void update() {
		int w = getWidth(), h = getHeight();
		for (int i = 0; i < mainButton.size(); i++) {
			mainButton.get(i).setFont(MenuManager.getButtonFont());
			mainButton.get(i).setBounds(w / 3, h / 3 + i * h / 6, w / 3, h / 8);
		}
		repaint();
	}

	@Override
	public void paintComponent(Graphics g) {
		g.drawImage(imageManager.getImageIcon("menuBackground").getImage(), 0, 0, getWidth(), getHeight(), null);
	}

}

class LeaveAction implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		System.exit(0);
	}

}

class SettingsAction implements ActionListener {
	@Override
	public void actionPerformed(ActionEvent e) {
		MenuManager.getInstance().setPanel(new SettingsPanel());
	}
}

class PlayAction implements ActionListener {
	@Override
	public void actionPerformed(ActionEvent e) {
		MenuManager.getInstance().setPanel(new PlayPanel());
	}
}