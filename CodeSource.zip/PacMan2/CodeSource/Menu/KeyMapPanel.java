package Menu;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;

import File.imageManager;
import Listener.Clavier;

@SuppressWarnings("serial")
public class KeyMapPanel extends PanelCustom {

	private ButtonCustom leave = new ButtonCustom("Sauvegarder/Quitter");
	private ArrayList<ButtonCustom> buttons = new ArrayList<>();
	private ButtonCustom selected = null;
	private KeyListenerSettings kls;

	void requeteFocusPanel(ButtonCustom b) {
		requestFocus();
		requestFocusInWindow();
		kls.setButton(b);
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		g.drawImage(imageManager.getImageIcon("backgroundKeyMap").getImage(), 0, 0, getWidth(), getHeight(), null);
	}

	@Override
	void init() {
		setLayout(null);
		Clavier.getInstance();

		for (Integer key : Clavier.getTouches().keySet()) {

			String value = Clavier.getTouches().get(key);
			buttons.add(new ButtonCustom(value + ":" + KeyEvent.getKeyText(key)));
			add(buttons.get(buttons.size() - 1));
			buttons.get(buttons.size() - 1).addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					selected = (ButtonCustom) e.getSource();
					update();
					requeteFocusPanel((ButtonCustom) e.getSource());
				}
			});
		}
		kls = new KeyListenerSettings(selected);

		addKeyListener(kls);
		add(leave);
		requestFocus();
		requestFocusInWindow();
	}

	@Override
	void update() {
		int w = getWidth(), h = getHeight();
		leave.setFont(MenuManager.getButtonFont());
		leave.setBounds(w / 3, h / 20 * 17, w / 3, h / 10);
		leave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MenuManager.getInstance().setPanel(new SettingsPanel());

			}
		});

		for (int x = 0; x < 5; x++)
			for (int y = 0; y < 5; y++)
				if (x * 5 + y < buttons.size()) {
					buttons.get(x * 5 + y).setFont(MenuManager.getTextFont());
					buttons.get(x * 5 + y).setBounds(x * w / 100 * 23 + w / 10, y * h / 8 + h / 10, w / 5, h / 10);
				}

		repaint();
	}

}

class KeyListenerSettings implements KeyListener {

	private ButtonCustom selectedButton;

	public KeyListenerSettings(ButtonCustom b) {
		this.selectedButton = b;
	}

	public void setButton(ButtonCustom b) {
		this.selectedButton = b;
	}

	public void keyTyped(KeyEvent e) {

	}

	public void keyPressed(KeyEvent e) {
		if (selectedButton != null) {
			if (!Clavier.getTouches().containsKey(e.getExtendedKeyCode())) {
				Iterator<Entry<Integer, String>> iterator = Clavier.getTouches().entrySet().iterator();
				while (iterator.hasNext()) {
					Entry<Integer, String> entry = iterator.next();
					if (entry.getValue().equals(selectedButton.getText().split(":")[0]))
						iterator.remove(); // Suppression de l'élément correspondant à la valeur

				}
				Clavier.getTouches().put(e.getExtendedKeyCode(), selectedButton.getText().split(":")[0]);
				selectedButton.setText(
						selectedButton.getText().split(":")[0] + ":" + KeyEvent.getKeyText(e.getExtendedKeyCode()));
			}

		}
	}

	@Override
	public void keyReleased(KeyEvent e) {

	}

}
