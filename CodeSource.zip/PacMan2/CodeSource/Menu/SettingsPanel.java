package Menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JSlider;

import File.imageManager;
import Listener.Clavier;

@SuppressWarnings("serial")
public class SettingsPanel extends PanelCustom {

	JSlider runTime = new JSlider();
	JLabel fpsLabel = new JLabel("FPS");
	ButtonCustom back = new ButtonCustom("Back");
	JCheckBox antiAlliasing = new JCheckBox("Anti-Aliasing");
	ButtonCustom save = new ButtonCustom("Save");
	ButtonCustom keyMappingButton = new ButtonCustom("Key Mapping");

	ArrayList<Section> sections = new ArrayList<>();

	void update() {
		int w = getWidth();
		int h = getHeight();

		for (int i = 0; i < sections.size(); i++) {
			sections.get(i).label.setFont(MenuManager.getButtonFont());
			sections.get(i).slider.setFont(MenuManager.getButtonFont());
			sections.get(i).label.setSize(w / 4, h / 10);
			sections.get(i).label.setLocation(w / 20 * 5, h / 10 + i * h / 5);
			sections.get(i).slider.setSize(w / 3, h / 10);
			sections.get(i).slider.setLocation(w / 10, h / 5 + i * h / 5);
		}
		fpsLabel.setFont(MenuManager.getButtonFont());
		fpsLabel.setSize(w / 3, h / 5);
		fpsLabel.setLocation(w / 20 * 5, h / 20 * 11);

		runTime.setFont(MenuManager.getButtonFont());
		runTime.setSize(w / 3, h / 5);
		runTime.setLocation(w / 10, h / 3 * 2);

		back.setFont(MenuManager.getButtonFont());
		back.setSize(w / 3, h / 10);
		back.setLocation(w / 10, h / 20 * 17);

		save.setSize(w / 3, h / 10);
		save.setFont(MenuManager.getButtonFont());
		save.setLocation(w - w / 10 - w / 3, h / 20 * 17);

		keyMappingButton.setFont(MenuManager.getButtonFont());
		keyMappingButton.setSize(w / 3, h / 10);
		keyMappingButton.setLocation(w / 10 * 6, h / 5);

		antiAlliasing.setFont(MenuManager.getButtonFont());
		antiAlliasing.setSize(w / 3, h / 10);
		antiAlliasing.setLocation(w / 10 * 7, h / 2);

	}

	void init() {
		setLayout(null);
		add(save);
		add(back);
		add(keyMappingButton);
		keyMappingButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MenuManager.getInstance().setPanel(new KeyMapPanel());
			}
		});
		add(antiAlliasing);

		sections.add(new Section(0, 120, "FPS", 10, 30));
		sections.add(new Section(0, 100, "Sound Volume", 10, 50));
		sections.add(new Section(0, 100, "Music Volume", 10, 50));

		for (int i = 0; i < sections.size(); i++) {
			add(sections.get(i).label);
			add(sections.get(i).slider);
		}
		back.addActionListener(new mainMenuAction());
		try (ObjectInputStream entreeObjet = new ObjectInputStream(
				new FileInputStream(imageManager.getUrlcourante() + "Settings.settings"))) {
			Reglage r = (Reglage) entreeObjet.readObject();
			sections.get(0).slider.setValue(r.getFps());
			sections.get(1).slider.setValue(r.getSoundVolum());
			sections.get(2).slider.setValue(r.getMusicVolum());
			antiAlliasing.setSelected(r.isAntiAliasing());
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}

		save.addActionListener(
				new saveAction(sections.get(0).slider, sections.get(1).slider, sections.get(2).slider, antiAlliasing));

	}

}

class Section {
	public JLabel label;
	public JSlider slider;

	public Section(int min, int max, String textLabel, int minor, int major) {
		label = new JLabel(textLabel);
		slider = new JSlider();
		slider.setMajorTickSpacing(major);
		slider.setMinorTickSpacing(minor);
		slider.setMinimum(min);
		slider.setMaximum(max);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
	}

}

class mainMenuAction implements ActionListener {
	@Override
	public void actionPerformed(ActionEvent e) {
		MenuManager.getInstance().setPanel(new mainMenuPanel());
	}
}

class saveAction implements ActionListener {
	JSlider sliderFPS, sliderSound, sliderMusics;
	JCheckBox antiAlliasingCheckbox;

	public saveAction(JSlider slider, JSlider slider2, JSlider slider3, JCheckBox anti) {
		this.sliderFPS = slider;
		this.sliderSound = slider2;
		this.sliderMusics = slider3;
		this.antiAlliasingCheckbox = anti;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Reglage r = new Reglage(sliderFPS.getValue(), sliderSound.getValue(), antiAlliasingCheckbox.isSelected(),
				sliderMusics.getValue(), Clavier.getTouches());
		

		try (ObjectOutputStream sortieObjet = new ObjectOutputStream(
				new FileOutputStream(File.imageManager.getUrlcourante() + "Settings.settings"))) {
			// Enregistrez l'objet dans le fichier
			sortieObjet.writeObject(r);
		} catch (IOException er) {
			er.printStackTrace();
		}
	}
}