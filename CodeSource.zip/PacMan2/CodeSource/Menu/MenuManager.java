package Menu;

import java.awt.Font;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.JFrame;

public class MenuManager {

	private final JFrame frame = new JFrame("Pac Man - Giovanni CARRE");
	private PanelCustom panel = null;
	private static Font buttonFont;
	private static Font textFont;

	private static MenuManager instance = null;

	public static MenuManager getInstance() {
		if (instance == null)
			instance = new MenuManager();
		return instance;
	}

	private MenuManager() {
	}

	public static Font getButtonFont() {
		return buttonFont;
	}

	public void init() {
		frame.setVisible(true);
		frame.setSize(1920, 1080);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);

		setPanel(new mainMenuPanel());
		frame.addComponentListener(new ComponentAdapter() {
			public void componentResized(ComponentEvent e) {
				update();
			}
		});
	}

	public void update() {
		textFont = new Font("Gabriela", Font.PLAIN, frame.getWidth() / 100);
		buttonFont = new Font("Gabriela", Font.PLAIN, frame.getWidth() / 40);
		panel.update();
	}

	public void setPanel(PanelCustom newPanel) {
		frame.getContentPane().removeAll();
		panel = newPanel;
		frame.getContentPane().add(panel);

		panel.init();
		panel.update();
		frame.pack();
		frame.revalidate();
		frame.setVisible(true);
	}

	public static Font getTextFont() {
		return textFont;
	}

	public void dispose() {
		frame.pack();
		frame.revalidate();
		frame.dispose();
		instance = null;
	}
}
