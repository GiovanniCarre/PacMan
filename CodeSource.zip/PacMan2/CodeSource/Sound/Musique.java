package Sound;

import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import File.imageManager;

public class Musique {
	private static Musique instance;
	private Clip clip;

	private Musique() {
		// Initialisez le lecteur audio
	}

	public static Musique getInstance() {
		if (instance == null) {
			instance = new Musique();
		}
		return instance;
	}

	public void chargerMusique(String nom) {
		try {
			if (clip != null && clip.isOpen()) {
				clip.close();
			}

			File fichierAudio = new File(imageManager.getUrlcourante()+"musics/"+nom+".mp3");
			AudioInputStream audioStream = AudioSystem.getAudioInputStream(fichierAudio);
			clip = AudioSystem.getClip();
			clip.open(audioStream);
		} catch (LineUnavailableException | UnsupportedAudioFileException | IOException e) {
			e.printStackTrace();
		}
	}

	public void jouer() {
	    if (!clip.isRunning()) {
	        clip.loop(Clip.LOOP_CONTINUOUSLY); // Configurer la lecture en boucle
	        clip.start();
	    }
	}


	public void stopper() {
		if (clip.isRunning()) {
			clip.stop();
			clip.setFramePosition(0);
		}
	}

	public void reglerVolume(float volume) {
		if (volume < 0.0f || volume > 1.0f) {
			throw new IllegalArgumentException("Le volume doit être compris entre 0.0 et 1.0");
		}
		FloatControl gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
		gainControl.setValue(20f * (float) Math.log10(volume));
	}
}
