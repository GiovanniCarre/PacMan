package StateButtonViewCommand;

import javax.swing.JButton;

public class PauseEtat implements Etat {

    private final JButton restart, run, step, pause;

    public PauseEtat(JButton restart, JButton run, JButton step, JButton pause) {
        this.restart = restart;
        this.run = run;
        this.step = step;
        this.pause = pause;
    }

    @Override
    public void gerer() {
        restart.setEnabled(true);
        run.setEnabled(true);
        step.setEnabled(true);
        pause.setEnabled(false);
    }
}
