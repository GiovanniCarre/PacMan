package StateButtonViewCommand;

public interface Etat {
    void gerer();
}

