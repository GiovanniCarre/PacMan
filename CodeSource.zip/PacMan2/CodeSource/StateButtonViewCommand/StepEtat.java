package StateButtonViewCommand;

import javax.swing.JButton;

public class StepEtat implements Etat {
    private final JButton restart, run, step, pause;

    public StepEtat(JButton restart, JButton run, JButton step, JButton pause) {
        this.restart = restart;
        this.run = run;
        this.step = step;
        this.pause = pause;
    }

    @Override
    public void gerer() {
        restart.setEnabled(true);
        run.setEnabled(true);
        step.setEnabled(true);
        pause.setEnabled(false);
    }
}
