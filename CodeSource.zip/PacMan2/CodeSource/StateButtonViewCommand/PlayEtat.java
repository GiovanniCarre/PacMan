package StateButtonViewCommand;

import javax.swing.JButton;

public class PlayEtat implements Etat {
    private final JButton restart, run, step, pause;

    public PlayEtat(JButton restart, JButton run, JButton step, JButton pause) {
        this.restart = restart;
        this.run = run;
        this.step = step;
        this.pause = pause;
    }

    @Override
    public void gerer() {
        restart.setEnabled(true);
        run.setEnabled(false);
        step.setEnabled(false);
        pause.setEnabled(true);
    }
}
