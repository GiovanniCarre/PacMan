package Observer;

import Moteur.Game;

public interface Observer {
	void update(Game game);
}
