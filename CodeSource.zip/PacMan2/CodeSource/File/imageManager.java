package File;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.swing.ImageIcon;

public class imageManager {

	public static final String urlCourante = imageManager.class.getProtectionDomain().getCodeSource().getLocation()
			.getFile();

	@SuppressWarnings("serial")
	private static Map<String, ImageIcon> imageMap = new LinkedHashMap<String, ImageIcon>(50, 0.75f, true) {
		@Override
		protected boolean removeEldestEntry(Map.Entry<String, ImageIcon> eldest) {
			return size() > 50;
		}
	};

	public static ImageIcon getImageIcon(String key) {
		// Vérifiez si l'image correspondant à la clé existe dans le LinkedHashMap
		if (imageMap.containsKey(key))
			return imageMap.get(key); // Renvoie l'ImageIcon correspondant à la clé
		else {
			// Si l'image n'existe pas, vérifiez si le fichier image existe
			String imagePath;
			if (!urlCourante.substring(urlCourante.length() - 4).equals(".jar"))
				imagePath = urlCourante + "../Ress/img/" + key + ".png";
			else
				imagePath = urlCourante.substring(0, urlCourante.lastIndexOf('/')) + "/Ress/img/" + key + ".png";

			File imageFile = new File(imagePath);

			if (imageFile.exists() && !imageFile.isDirectory()) {
				ImageIcon newIcon = new ImageIcon(imagePath);
				imageMap.put(key, newIcon);
				return newIcon;
			} else {
				// Si le fichier image n'existe pas, renvoyez une erreur
				throw new IllegalArgumentException(
						"L'image avec la clé '" + imageFile.getAbsolutePath() + "' n'existe pas.");
				
			}
		}
	}
	
	public static String getUrlcourante() {
		String imagePath;
		if (!urlCourante.substring(urlCourante.length() - 4).equals(".jar"))
			imagePath = urlCourante + "../Ress/";
		else
			imagePath = urlCourante.substring(0, urlCourante.lastIndexOf('/')) + "/Ress/";
		return imagePath;

	}

}
